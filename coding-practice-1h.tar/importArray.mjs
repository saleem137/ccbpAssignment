import values from "./exportArray.mjs";
console.log(values);
